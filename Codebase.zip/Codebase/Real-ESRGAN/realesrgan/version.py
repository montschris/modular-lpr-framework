# GENERATED VERSION FILE
# TIME: Sat Apr 19 00:53:06 2025
__version__ = '0.3.0'
__gitsha__ = 'a4abfb2'
version_info = (0, 3, 0)
